//
// Created by Brent Van Wynsberge on 7/10/17.
//

#ifndef PROJECT_BIT_OPERATIONS_H
#define PROJECT_BIT_OPERATIONS_H
//Zet een byte om in zijn binaire patroon
#define BYTE_TO_BINARY_PATTERN "%c%c%c%c%c%c%c%c"
#define BYTE_TO_BINARY(byte)  \
  ((byte) & 0x80 ? '1' : '0'), \
  ((byte) & 0x40 ? '1' : '0'), \
  ((byte) & 0x20 ? '1' : '0'), \
  ((byte) & 0x10 ? '1' : '0'), \
  ((byte) & 0x08 ? '1' : '0'), \
  ((byte) & 0x04 ? '1' : '0'), \
  ((byte) & 0x02 ? '1' : '0'), \
  ((byte) & 0x01 ? '1' : '0')
#endif //PROJECT_BIT_OPERATIONS_H
