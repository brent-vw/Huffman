//
// Created by Brent Van Wynsberge on 1/12/17.
//

#ifndef PROJECT_BLOCK_H
#define PROJECT_BLOCK_H
#define BLOCK_SIZE 255;
void block_decode();
void block_encode();
#endif //PROJECT_BLOCK_H
